package com.Uddin.rubrica;

import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Service
public class CsvRubricaService {

    private final String FILE_PATH = "rubrica.csv";

    public List<Contatto> leggiContatti() {
        List<Contatto> contatti = new ArrayList<>();
        File file = new File(FILE_PATH);
        if (!file.exists()) return contatti;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String riga;
            while ((riga = reader.readLine()) != null) {
                String[] campi = riga.split(",", -1);
                if (campi.length >= 4) {
                    Long id = Long.parseLong(campi[0]);
                    String nome = unescape(campi[1]);
                    String cognome = unescape(campi[2]);
                    String telefono = unescape(campi[3]);
                    contatti.add(new Contatto(id, nome, cognome, telefono));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return contatti;
    }

    public void salvaContatti(List<Contatto> contatti) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Contatto c : contatti) {
                writer.write(c.getId() + "," + escape(c.getNome()) + "," + escape(c.getCognome()) + "," + escape(c.getTelefono()));
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String escape(String text) {
        if (text == null) return "";
        return text.replace(",", "\\,").replace("\n", "\\n");
    }

    private String unescape(String text) {
        if (text == null) return "";
        return text.replace("\\,", ",").replace("\\n", "\n");
    }
}
