package com.Uddin.rubrica;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@Controller
public class RubricaController {

    private List<Contatto> contatti = new ArrayList<>();
    private AtomicLong idGenerator = new AtomicLong(1);

    @Autowired
    private CsvRubricaService csvService;

    @PostConstruct
    public void init() {
        contatti = csvService.leggiContatti();
        long maxId = contatti.stream()
                .mapToLong(Contatto::getId)
                .max()
                .orElse(0);
        idGenerator.set(maxId + 1);
    }

    @GetMapping("/")
    public String lista(Model model) {
        model.addAttribute("contatti", contatti);
        return "index";
    }

    @GetMapping("/aggiungi")
    public String mostraForm(Model model) {
        model.addAttribute("contatto", new Contatto());
        return "form";
    }

    @PostMapping("/salva")
    public String salva(@ModelAttribute Contatto contatto) {
        if (contatto.getId() == null) {
            contatto.setId(idGenerator.getAndIncrement());
            contatti.add(contatto);
        } else {
            for (int i = 0; i < contatti.size(); i++) {
                if (Objects.equals(contatti.get(i).getId(), contatto.getId())) {
                    contatti.set(i, contatto);
                    break;
                }
            }
        }
        csvService.salvaContatti(contatti);
        return "redirect:/";
    }

    @GetMapping("/modifica/{id}")
    public String modifica(@PathVariable Long id, Model model) {
        Contatto contatto = contatti.stream()
                .filter(c -> c.getId().equals(id))
                .findFirst()
                .orElse(null);
        model.addAttribute("contatto", contatto);
        return "form";
    }

    @GetMapping("/elimina/{id}")
    public String elimina(@PathVariable Long id) {
        contatti.removeIf(c -> c.getId().equals(id));
        csvService.salvaContatti(contatti);
        return "redirect:/";
    }
}